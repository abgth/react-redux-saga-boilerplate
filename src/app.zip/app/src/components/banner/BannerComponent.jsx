import React from 'react'
import './BannerComponent.css'

const BannerComponent = () => (
    <div className="container">

        <div className="BannerComponent jumbotron jumbotron-fluid"
            style={{ marginTop: 74, marginBottom: 0 }}
        >
            <div className="container text-center">
                <img src="./../../assets/dart-green.png" />
                <p className="lead">Success</p>
            </div>
        </div>
    </div>
)

export default BannerComponent