import React, { Component } from 'react';
import HeaderComponent from './header/HeaderComponent'
import BannerComponent from './banner/BannerComponent'
import CurrentStatusByService from './status/CurrentStatusByService'

export default class App extends Component {
  render() {
    return (
      <div>
        <HeaderComponent />
        <BannerComponent />
        <CurrentStatusByService />
        </div>
    );
  }
}
