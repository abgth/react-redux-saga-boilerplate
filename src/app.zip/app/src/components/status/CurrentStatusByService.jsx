import React from 'react'

const CurrentStatusByService = () => (
    <div className="container current-status-by-service">
        <div className="list-group" className="section justify_content_center"> 
            <a href="#" className="list-group-item list-group-item-action" style={{backgroundColor: `#c1e5ff`}}> 
                Current Status by Service
                <span className="status-indicators text-right">
                    <span className="stats-text"><i className="fas fa-check-circle green"></i>No Issues</span>
                    <span className="stats-text"><i className="fas fa-wrench purple"></i>Maintenance</span>
                    <span className="stats-text"><i className="fas fa-minus-circle red"></i>Outage</span>
                </span>
            </a> 
            <a href="#" className="list-group-item list-group-item-action stats-list-item">
                Jhipster
                <i className="fas fa-check-circle green"></i>
            </a> 
            <a href="#" className="list-group-item list-group-item-action stats-list-item">
                UAA
                <i className="fas fa-check-circle green"></i>
            </a> 
            <a href="#" className="list-group-item list-group-item-action stats-list-item">
                User-Management
                <i className="fas fa-check-circle green"></i>
            </a> 
            <a href="#" className="list-group-item list-group-item-action stats-list-item">
                Test-Automation
                <i className="fas fa-check-circle green"></i>
            </a> 
            <a href="#" className="list-group-item list-group-item-action stats-list-item">
                Gateway(WSO2)
                <i className="fas fa-check-circle green"></i>
            </a>     
        </div>
    </div>
)

export default CurrentStatusByService 